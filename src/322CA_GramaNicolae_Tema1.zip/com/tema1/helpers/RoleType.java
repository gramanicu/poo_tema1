package com.tema1.helpers;

public enum RoleType { Sheriff, Trader }
