# Sheriff of Nottingham - 1st Object-Oriented Programming Course Homework

The problem statement can be found [here](http://elf.cs.pub.ro/poo/teme/tema). It is an adapted version of the Sheriff of Nottingham "board game".

## Table of Contents

- [Sheriff of Nottingham - 1st Object-Oriented Programming Course Homework](#sheriff-of-nottingham---1st-object-oriented-programming-course-homework)
  - [Table of Contents](#table-of-contents)

© 2019 Grama Nicolae, 322CA
